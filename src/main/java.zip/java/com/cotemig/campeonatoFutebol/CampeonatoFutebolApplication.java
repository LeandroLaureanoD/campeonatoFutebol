package com.cotemig.campeonatoFutebol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CampeonatoFutebolApplication {

	public static void main(String[] args) {
		SpringApplication.run(CampeonatoFutebolApplication.class, args);
	}

}
